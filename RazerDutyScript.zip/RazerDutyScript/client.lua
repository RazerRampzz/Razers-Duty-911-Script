local dutyBlip = nil
local isOnDuty = false
local playerBlips = {}

RegisterNetEvent("duty:setStatus", function(status, department)
    isOnDuty = status
    if status then
        TriggerEvent("chat:addMessage", {
            color = { 0, 255, 0 },
            multiline = true,
            args = { "^2[Duty]", "^7You are now ^2on duty^7 as ^3" .. department }
        })
        createSelfBlip(department)
    else
        TriggerEvent("chat:addMessage", {
            color = { 255, 50, 50 },
            multiline = true,
            args = { "^1[Duty]", "^7You are now ^1off duty" }
        })
        removeSelfBlip()
        removeAllPlayerBlips()
    end
end)

RegisterNetEvent("duty:createBlipForPlayer", function(targetId, department)
    if not isOnDuty then return end

    local function createBlip()
        local player = GetPlayerFromServerId(targetId)
        local targetPed = GetPlayerPed(player)
        if not DoesEntityExist(targetPed) then return false end

        -- Remove existing blip if it exists
        if playerBlips[targetId] then
            RemoveBlip(playerBlips[targetId])
        end

        local blip = AddBlipForEntity(targetPed)
        SetBlipSprite(blip, 1)
        SetBlipScale(blip, 0.9)
        SetBlipColour(blip, 29)
        SetBlipCategory(blip, 7)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString("On Duty - " .. department)
        EndTextCommandSetBlipName(blip)
        playerBlips[targetId] = blip
        return true
    end

    -- Retry if entity doesn't exist yet (OneSync safe)
    local attempts = 0
    local maxAttempts = 20
    local retryDelay = 500

Citizen.CreateThread(function()
    while attempts < maxAttempts do
        if createBlip() then break end
        attempts = attempts + 1
        Wait(retryDelay)
    end
end)
end)

RegisterNetEvent("duty:removeBlipForAll", function(targetId)
    if playerBlips[targetId] then
        RemoveBlip(playerBlips[targetId])
        playerBlips[targetId] = nil
    end
end)

RegisterNetEvent("duty:notify911", function(caller, msg, street, coords)
    if not isOnDuty then return end

    local message = "911 Call from " .. caller .. ": " .. msg .. " @ " .. street

    local success = pcall(function()
        exports['mythic_notify']:DoCustomHudText('inform', message, 30000)
    end)

    if not success then
        TriggerEvent("chat:addMessage", {
            color = { 255, 0, 0 },
            multiline = true,
            args = { "^1[911]", message }
        })
    end

    local blip = AddBlipForCoord(coords.x, coords.y, coords.z)
    SetBlipSprite(blip, 161)
    SetBlipScale(blip, 1.2)
    SetBlipColour(blip, 1)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("911 Call")
    EndTextCommandSetBlipName(blip)

    Citizen.SetTimeout(300000, function()
        RemoveBlip(blip)
    end)
end)

RegisterNetEvent("duty:getLocation", function(msg, caller)
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local streetName = GetStreetNameFromHashKey(GetStreetNameAtCoord(coords.x, coords.y, coords.z))
    TriggerServerEvent("duty:send911ToDuty", caller, msg, streetName, coords)
end)

AddEventHandler("onClientPlayerLeave", function(player)
    local id = GetPlayerServerId(player)
    if playerBlips[id] then
        RemoveBlip(playerBlips[id])
        playerBlips[id] = nil
    end
end)

function createSelfBlip(department)
    local ped = PlayerPedId()
    dutyBlip = AddBlipForEntity(ped)
    SetBlipSprite(dutyBlip, 1)
    SetBlipScale(dutyBlip, 0.9)
    SetBlipColour(dutyBlip, 29)
    SetBlipCategory(dutyBlip, 7)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("On Duty - " .. department)
    EndTextCommandSetBlipName(dutyBlip)
end

function removeSelfBlip()
    if dutyBlip then
        RemoveBlip(dutyBlip)
        dutyBlip = nil
    end
end

function removeAllPlayerBlips()
    for id, blip in pairs(playerBlips) do
        if blip then
            RemoveBlip(blip)
        end
    end
    playerBlips = {}
end
