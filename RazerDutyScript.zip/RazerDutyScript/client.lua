local dutyBlip = nil
local isOnDuty = false
local playerBlips = {}

RegisterNetEvent("duty:setStatus", function(status, department)
    isOnDuty = status
    if status then
        TriggerEvent("chat:addMessage", {
            color = { 0, 255, 0 },
            multiline = true,
            args = { "^2[Duty]", "^7You are now ^2on duty^7 as ^3" .. department }
        })
        createSelfBlip(department)
    else
        TriggerEvent("chat:addMessage", {
            color = { 255, 50, 50 },
            multiline = true,
            args = { "^1[Duty]", "^7You are now ^1off duty" }
        })
        removeSelfBlip()
        removeAllPlayerBlips()
    end
end)

RegisterNetEvent("duty:createBlipForPlayer", function(targetId, department)
    if not isOnDuty then return end
    local targetPed = GetPlayerPed(GetPlayerFromServerId(targetId))
    if DoesEntityExist(targetPed) then
        local blip = AddBlipForEntity(targetPed)
        SetBlipSprite(blip, 1)
        SetBlipScale(blip, 0.9)
        SetBlipColour(blip, 29)
        SetBlipCategory(blip, 7)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString("On Duty - " .. department)
        EndTextCommandSetBlipName(blip)
        playerBlips[targetId] = blip
    end
end)

RegisterNetEvent("duty:removeBlipForAll", function(targetId)
    local blip = playerBlips[targetId]
    if blip then
        RemoveBlip(blip)
        playerBlips[targetId] = nil
    end
end)

RegisterNetEvent("duty:notify911", function(caller, msg, street, coords)
    if not isOnDuty then return end

    local message = "911 Call from " .. caller .. ": " .. msg .. " @ " .. street

    -- 🔧 Use correct Mythic Notify export
    local success = pcall(function()
        exports['mythic_notify']:DoCustomHudText('inform', message, 30000)
    end)

    if not success then
        -- fallback to chat with style
        TriggerEvent("chat:addMessage", {
            color = { 255, 0, 0 },
            multiline = true,
            args = { "^1[911]", message }
        })
    end

    -- 📍 Add 911 map blip for 5 mins
    local blip = AddBlipForCoord(coords.x, coords.y, coords.z)
    SetBlipSprite(blip, 161)
    SetBlipScale(blip, 1.2)
    SetBlipColour(blip, 1)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("911 Call")
    EndTextCommandSetBlipName(blip)

    Citizen.SetTimeout(300000, function()
        RemoveBlip(blip)
    end)
end)

RegisterNetEvent("duty:getLocation", function(msg, caller)
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local streetName = GetStreetNameFromHashKey(GetStreetNameAtCoord(coords.x, coords.y, coords.z))
    TriggerServerEvent("duty:send911ToDuty", caller, msg, streetName, coords)
end)

function createSelfBlip(department)
    local ped = PlayerPedId()
    dutyBlip = AddBlipForEntity(ped)
    SetBlipSprite(dutyBlip, 1)
    SetBlipScale(dutyBlip, 0.9)
    SetBlipColour(dutyBlip, 29)
    SetBlipCategory(dutyBlip, 7)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("On Duty - " .. department)
    EndTextCommandSetBlipName(dutyBlip)
end

function removeSelfBlip()
    if dutyBlip then
        RemoveBlip(dutyBlip)
        dutyBlip = nil
    end
end

function removeAllPlayerBlips()
    for _, blip in pairs(playerBlips) do
        RemoveBlip(blip)
    end
    playerBlips = {}
end
