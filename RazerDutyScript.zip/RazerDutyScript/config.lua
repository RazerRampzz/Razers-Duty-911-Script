Config = {}

-- Discord Webhooks
Config.Webhooks = {
    OnDuty = "ADD WEBHOOK HERE",
    OffDuty = "ADD WEBHOOK HERE"
}

-- Departments Config
Config.Departments = {
    LSPD = { label = "Los Santos Police Department", ace = "leo" },
    SAST = { label = "San Andreas State Troopers", ace = "leo" },
    BCSO = { label = "Blaine County Sheriff's Office", ace = "leo" },
    FBI =  { label = "Federal Bureau of Investigation", ace = "leo" },
    NG =   { label = "National Guard", ace = "leo" },
    DOT =  { label = "Department of Transportation", ace = "leo" },
    SS =   { label = "Secret Service", ace = "leo" }
}
