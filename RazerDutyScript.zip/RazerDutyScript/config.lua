Config = {}

-- Discord Webhooks
Config.Webhooks = {
    OnDuty = "https://discord.com/api/webhooks/1349657609757659198/ps3xdC8wI5IXwx1ic3GjZoEGrbkXBqtmLy3wHigLS9OeO_K-nlGFEgmAdlqDxVE7lk8F",
    OffDuty = "https://discord.com/api/webhooks/1349657609757659198/ps3xdC8wI5IXwx1ic3GjZoEGrbkXBqtmLy3wHigLS9OeO_K-nlGFEgmAdlqDxVE7lk8F"
}

-- Departments Config
Config.Departments = {
    LSPD = { label = "Los Santos Police Department", ace = "leo" },
    SAST = { label = "San Andreas State Troopers", ace = "leo" },
    BCSO = { label = "Blaine County Sheriff's Office", ace = "leo" },
    FBI =  { label = "Federal Bureau of Investigation", ace = "leo" },
    NG =   { label = "National Guard", ace = "leo" },
    DOT =  { label = "Department of Transportation", ace = "leo" },
    SS =   { label = "Secret Service", ace = "leo" }
}
