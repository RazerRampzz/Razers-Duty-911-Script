fx_version 'cerulean'
game 'gta5'

author 'RazerRampz'
description 'Police Duty & 911 System'
version '1.0.0'

shared_script 'config.lua'
client_scripts {
    'client.lua'
}
server_scripts {
    'server.lua'
}
