local dutyStatus = {}
local dutyStartTime = {}

RegisterCommand("duty", function(source, args)
    local department = args[1] and string.upper(args[1])
    if not department or not Config.Departments[department] then
        TriggerClientEvent("chat:addMessage", source, {
            args = { "System", "Invalid department. Try /duty LSPD" }
        })
        return
    end

    -- ✅ Fixed ACE permission check
    if not IsPlayerAceAllowed(source, "command.duty") then
        TriggerClientEvent("chat:addMessage", source, {
            args = { "System", "Insufficient permissions." }
        })
        return
    end

    local playerId = tostring(source)
    if dutyStatus[playerId] then
        local duration = os.time() - dutyStartTime[playerId]
        sendWebhook(Config.Webhooks.OffDuty, GetPlayerName(source) .. " went OFF duty as " .. dutyStatus[playerId] .. " after " .. os.date("!%X", duration))
        dutyStatus[playerId] = nil
        dutyStartTime[playerId] = nil

        TriggerClientEvent("duty:setStatus", source, false)
        TriggerClientEvent("duty:removeBlipForAll", -1, source)
    else
        dutyStatus[playerId] = department
        dutyStartTime[playerId] = os.time()

        sendWebhook(Config.Webhooks.OnDuty, GetPlayerName(source) .. " is now ON duty as " .. department)
        TriggerClientEvent("duty:setStatus", source, true, department)

        -- Sync blips with all other on-duty players
        for id, dept in pairs(dutyStatus) do
            if tonumber(id) ~= source then
                TriggerClientEvent("duty:createBlipForPlayer", tonumber(id), source, department)
                TriggerClientEvent("duty:createBlipForPlayer", source, tonumber(id), dept)
            end
        end
    end
end, false)

RegisterCommand("911", function(source, args)
    local msg = table.concat(args, " ")
    local name = GetPlayerName(source)

    -- Send confirmation message to the caller
    TriggerClientEvent("chat:addMessage", source, {
        color = { 0, 255, 0 },
        args = { "^3[911]^7", "Call successful. Emergency services are on their way." }
    })

    -- Get caller location and notify responders
    TriggerClientEvent("duty:getLocation", source, msg, name)
end, false)

RegisterNetEvent("duty:send911ToDuty", function(name, msg, street, coords)
    for id, dept in pairs(dutyStatus) do
        TriggerClientEvent("duty:notify911", tonumber(id), name, msg, street, coords)
    end
end)

function sendWebhook(url, message)
    PerformHttpRequest(url, function() end, "POST", json.encode({
        username = "Duty Logs",
        content = message
    }), { ["Content-Type"] = "application/json" })
end
